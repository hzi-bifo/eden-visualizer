# eden-visualizer

online-hosted: https://pmuench.shinyapps.io/eden-visualizer/

when using eden, this application will run inside a docker container and can be accessed using localhost
